package com.test.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.test.bean.Login;
import com.test.service.LoginService;
import com.test.util.EncryptionDecryption;
import com.test.util.LoginValidator;

@Controller
public class LoginController {

	@Autowired
	LoginService loginService;

	@RequestMapping("/login.html/{username}")
	public ModelAndView verifyLoginInfo(@PathVariable("username") String username, ModelAndView model,
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Inside EmailVerification.");
		System.out.println("Username = " + username);
		Login log = loginService.getLoginDetails(username);
		if (log.getStatus() == 0) {
			int status = 1;
			log.setStatus(status);
			loginService.updateLogin(log);
		}
		model.addObject("username", username);
		model.setViewName("emailVerified");
		return model;
	}

	@RequestMapping(value = "/loggedin", method = RequestMethod.POST)
	public ModelAndView login(@ModelAttribute("login") Login login, ModelAndView model, HttpServletRequest request,
			HttpServletResponse response, BindingResult result) throws Exception {

		LoginValidator validator = new LoginValidator();
		validator.validate(login, result);
		if (null != result.getAllErrors() && result.getAllErrors().size() > 0) {
			List<ObjectError> error = result.getAllErrors();
			request.setAttribute("msg", error);
			return model;
		}

		Login log = loginService.getLoginDetails(login.getUsername());
		if (null != log) {
			if (log.getStatus() == 1) {
				if (login.getPassword().equals(EncryptionDecryption.decrypt(log.getPassword()))) {
					HttpSession session = request.getSession();
					session.setAttribute("username", login.getUsername());
					model.setViewName("loginSuccess");
				} else {
					model.addObject("msg", "Please provide correct information.");
					model.setViewName("login");
				}
			} else {
				model.addObject("msg", "Account does not exist");
				model.setViewName("login");
			}
		} else {
			model.addObject("msg", "Please provide correct information.");
			model.setViewName("login");
		}

		return model;
	}
}
