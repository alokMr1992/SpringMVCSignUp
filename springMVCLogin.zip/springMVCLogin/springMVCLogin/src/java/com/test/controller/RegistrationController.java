package com.test.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.test.bean.CaptchaResponse;
import com.test.bean.Login;
import com.test.bean.User;
import com.test.service.RegisterService;
import com.test.util.EncryptionDecryption;
import com.test.util.MailSender;

@Controller
public class RegistrationController {

	@Autowired
	RegisterService registerService;

	private MailSender ms = new MailSender();
	private String secretParameter = "Your Private Secret Key";

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView addUser(@ModelAttribute("user") User user, ModelAndView model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String recap = request.getParameter("g-recaptcha-response");

		// Send get request to Google reCaptcha server with secret key
		URL url = new URL("https://www.google.com/recaptcha/api/siteverify?secret=" + secretParameter + "&response="
				+ recap + "&remoteip=" + request.getRemoteAddr());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		String line, outputString = "";
		BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		while ((line = reader.readLine()) != null) {
			outputString += line;
		}
		System.out.println("Output String = " + outputString);

		// Convert response into Object
		CaptchaResponse capRes = new Gson().fromJson(outputString, CaptchaResponse.class);

		// Verify whether the input from Human or Robot
		if (capRes.isSuccess()) {
			// Input by Human
			if (null == registerService.getUser(user.getUsername())) {
				registerService.addUser(user);
				String username = user.getUsername();
				String dob = user.getDob();
				System.out.println(dob);
				String password = username + "@" + dob;
				String encryptedPassword = EncryptionDecryption.encrypt(password);
				Login log = new Login();
				log.setUsername(username);
				log.setPassword(encryptedPassword);
				System.out.println("log : " + log.getUsername() + " : " + log.getPassword());
				System.out.println("In Registration Controller.");
				registerService.addLogin(log);
				System.out.println("After login add.");

				String from = "Your Email Server Id";
				String to = user.getEmail();
				String subject = "Verification";

				String msgPart = "Dear " + username + ",\n\n" + "Thank you for joining us.\n" + "Your password is : "
						+ password + "\n<a href=\"http://localhost:8080/springMVCLogin/login.html/"+username+"\">Click here to verify your account</a>";
				String footer = "\n\nAll the best!";

				String message = msgPart + footer;
				String login = "Your Email Server Id";
				String emailPassword = "Your Email Server Password";

				ms.mailsender(from, to, subject, message, login, emailPassword);
				model.addObject("username", username);
				model.setViewName("registrationSuccess");
			} else {
				model.addObject("msg", "username already exists, please choose unique username.");
				model.setViewName("register");
			}
		} else {
			// Input by Robot
			model.addObject("msg", "You have missed the captcha.");
			model.setViewName("register");
		}
		return model;
	}
}