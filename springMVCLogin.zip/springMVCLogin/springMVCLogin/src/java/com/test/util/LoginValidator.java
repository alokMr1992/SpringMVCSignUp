package com.test.util;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class LoginValidator implements Validator{

	@Override
	public boolean supports(@SuppressWarnings("rawtypes") Class clazz) {		
		return LoginValidator.class.equals(clazz);
	}

	@Override
	public void validate(Object form, Errors errors) {		
	}

}
