package com.test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.bean.Login;
import com.test.dao.LoginDao;

@Service("loginService")
public class LoginService {

	@Autowired
	LoginDao loginDao;
	
	/*@Transactional
	public void addLogin(Login log) {
		System.out.println("LoginService : "+log);
		loginDao.addLogin(log);
	}*/

	@Transactional
	public Login getLoginDetails(String username) {
		return loginDao.getLoginDetails(username);
	}

	@Transactional
	public void updateLogin(Login log) {
		loginDao.updateLogin(log);
		
	}

}
