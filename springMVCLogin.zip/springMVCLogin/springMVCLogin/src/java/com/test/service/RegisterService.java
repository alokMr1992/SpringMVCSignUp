package com.test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.bean.Login;
import com.test.bean.User;
import com.test.dao.RegisterDao;

@Service("registerService")
public class RegisterService {

	@Autowired
	RegisterDao registerDao;

	@Transactional
	public void addUser(User user) {
		registerDao.addUser(user);
	}
	
	@Transactional
	public User getUser(String username){
		return registerDao.getUser(username);
	}

	@Transactional
	public void addLogin(Login log) {
		System.out.println("In Register Service : "+log);
		registerDao.addLogin(log);
	}
}
