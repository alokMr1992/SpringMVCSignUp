package com.test.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.test.bean.Login;
import com.test.bean.User;

@Repository
public class RegisterDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	public void addUser(User user) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(user);		
	}
	
	public User getUser(String username){
		Session session = this.sessionFactory.getCurrentSession();
		User user = (User) session.get(User.class, username);
		return user;
	}
	
	public void addLogin(Login log) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(log);	
	}
}
