package com.test.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.test.bean.Login;

@Repository
public class LoginDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	/*public void addLogin(Login log) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(log);	
	}*/

	public Login getLoginDetails(String username) {
		System.out.println("Inside LoginDao.");
		Session session = this.sessionFactory.getCurrentSession();
		Login login = (Login) session.get(Login.class, username);
		return login;
	}

	public void updateLogin(Login log) {
		sessionFactory.getCurrentSession().update(log);
	}

}
